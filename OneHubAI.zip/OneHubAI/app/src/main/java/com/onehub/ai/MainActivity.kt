package com.onehub.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 40)
        }

        val title = TextView(this).apply {
            text = "OneHub AI"
            textSize = 30f
        }
        val subtitle = TextView(this).apply {
            text = "Food, grocery and smart shortcuts in one place"
            textSize = 16f
        }
        val command = EditText(this).apply {
            hint = "Try: Open Swiggy"
        }
        val run = Button(this).apply { text = "Ask OneHub" }
        val zomato = Button(this).apply { text = "Open Zomato" }
        val swiggy = Button(this).apply { text = "Open Swiggy" }
        val blinkit = Button(this).apply { text = "Open Blinkit" }
        val other = Button(this).apply { text = "Other Apps" }

        listOf(title, subtitle, command, run, zomato, swiggy, blinkit, other).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 18) })
        }

        setContentView(root)

        zomato.setOnClickListener { openAppOrWeb("com.application.zomato", "https://www.zomato.com") }
        swiggy.setOnClickListener { openAppOrWeb("in.swiggy.android", "https://www.swiggy.com") }
        blinkit.setOnClickListener { openAppOrWeb("com.grofers.customerapp", "https://blinkit.com") }
        other.setOnClickListener {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MARKET))
        }
        run.setOnClickListener {
            val q = command.text.toString().lowercase()
            when {
                "zomato" in q -> openAppOrWeb("com.application.zomato", "https://www.zomato.com")
                "swiggy" in q -> openAppOrWeb("in.swiggy.android", "https://www.swiggy.com")
                "blinkit" in q -> openAppOrWeb("com.grofers.customerapp", "https://blinkit.com")
                else -> Toast.makeText(this, "AI chat can be connected in the next version.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openAppOrWeb(packageName: String, url: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
